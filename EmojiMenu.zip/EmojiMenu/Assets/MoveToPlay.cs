﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveToPlay : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Debug.Log ("Hi we made it");
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}/*/
using UnityEngine;
using UnityEngine.SceneManagement;

public class MoveToPlay : MonoBehaviour
{
	public void NextScene()
	{
		SceneManager.LoadScene("MapSelect");
	}
}*/